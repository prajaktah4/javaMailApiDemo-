package com.MainApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaMailApiDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
